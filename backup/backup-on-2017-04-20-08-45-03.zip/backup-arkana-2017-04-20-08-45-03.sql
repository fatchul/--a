#
# TABLE STRUCTURE FOR: course
#

DROP TABLE IF EXISTS `course`;

CREATE TABLE `course` (
  `id_course` varchar(100) NOT NULL,
  `title` varchar(200) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `duration` int(10) NOT NULL,
  PRIMARY KEY (`id_course`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: course_gallery
#

DROP TABLE IF EXISTS `course_gallery`;

CREATE TABLE `course_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` varchar(100) NOT NULL,
  `meta` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: course_material
#

DROP TABLE IF EXISTS `course_material`;

CREATE TABLE `course_material` (
  `id_course_material` varchar(100) NOT NULL,
  `id_silabus` varchar(100) NOT NULL,
  `title_material` varchar(1000) NOT NULL,
  `meta` varchar(1000) NOT NULL,
  PRIMARY KEY (`id_course_material`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: course_tag
#

DROP TABLE IF EXISTS `course_tag`;

CREATE TABLE `course_tag` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `id_tag` varchar(100) NOT NULL,
  `id_course` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: course_tr
#

DROP TABLE IF EXISTS `course_tr`;

CREATE TABLE `course_tr` (
  `id_course_enrollment` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` varchar(100) NOT NULL,
  `id_user` varchar(15) NOT NULL,
  `date_enrollment` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_course_enrollment`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `migrations` (`version`) VALUES ('0');


#
# TABLE STRUCTURE FOR: school
#

DROP TABLE IF EXISTS `school`;

CREATE TABLE `school` (
  `id_school` varchar(15) NOT NULL,
  `school_name` varchar(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `headmaster` varchar(200) DEFAULT NULL,
  `pic` varchar(200) NOT NULL DEFAULT 'sch.jpg',
  `reg_number_ministry` varchar(200) DEFAULT NULL,
  `token_reg` varchar(200) NOT NULL,
  `token_forgot_pass` varchar(200) NOT NULL,
  `is_subscribe` int(1) NOT NULL DEFAULT '1',
  `is_valid` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_school`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `school` (`id_school`, `school_name`, `address`, `contact_person`, `email`, `password`, `update_at`, `last_login`, `headmaster`, `pic`, `reg_number_ministry`, `token_reg`, `token_forgot_pass`, `is_subscribe`, `is_valid`) VALUES ('205325', 'SMKN 2 SALATIGA', '', '', 'fPVJeHxX', '$2y$12$d5oU7QryBJDN2TgaCZ8gg.DJziTAR5Z4V45J.TjdLBkr829nwfmKW', '2017-04-20 06:53:25', '0000-00-00 00:00:00', '', '', '', 'qLfw0w7rJVN06065HPKzD45XauEXC4tP4orLzW80ijeQ1dlZRB', 'IwajqL6x8SaJqhbPEfnrgPY0xXPbrcSsTBxJt4T7h8A8EavhQ', '1', '0');
INSERT INTO `school` (`id_school`, `school_name`, `address`, `contact_person`, `email`, `password`, `update_at`, `last_login`, `headmaster`, `pic`, `reg_number_ministry`, `token_reg`, `token_forgot_pass`, `is_subscribe`, `is_valid`) VALUES ('205603', 'SMKN 1 SALATIGA', '', '', 'fPVJeHxX', '$2y$12$dgViArM8jYJwXpGw.ewgJO3FXtHm480oneW2J6HtPnk4kfSUs8.ru', '2017-04-20 12:58:57', '0000-00-00 00:00:00', '', '', '', 'Vu7ggoC84c0u6VPZtkMhwFtVYhovk3DGbMXZzfZ8ud2n3Y0dKT', 'sygmg6QVqSjqFbYFXLA0nv5km1CSGhy3Z2LxTTo6Bf0JDieJH', '1', '0');


#
# TABLE STRUCTURE FOR: silabus
#

DROP TABLE IF EXISTS `silabus`;

CREATE TABLE `silabus` (
  `id_silabus` varchar(100) NOT NULL,
  `id_course` varchar(100) NOT NULL,
  `title_silabus` varchar(1000) NOT NULL,
  `no_urut` int(11) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_silabus`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: tag
#

DROP TABLE IF EXISTS `tag`;

CREATE TABLE `tag` (
  `id_tag` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `update_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id_user` varchar(15) NOT NULL,
  `id_school` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `role` varchar(100) DEFAULT NULL,
  `nama` varchar(200) DEFAULT NULL,
  `dob` varchar(200) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `gender` varchar(25) NOT NULL,
  `profile` text,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_join` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `token_reg` varchar(200) DEFAULT NULL,
  `token_forgot_pass` varchar(200) DEFAULT NULL,
  `level` varchar(15) NOT NULL,
  `address` text,
  `facebook_url` varchar(200) DEFAULT NULL,
  `pict_name` varchar(200) DEFAULT NULL,
  `is_subscribe` int(1) NOT NULL DEFAULT '1',
  `is_valid` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `user` (`id_user`, `id_school`, `email`, `role`, `nama`, `dob`, `password`, `gender`, `profile`, `last_login`, `date_join`, `token_reg`, `token_forgot_pass`, `level`, `address`, `facebook_url`, `pict_name`, `is_subscribe`, `is_valid`) VALUES ('194149', '19', 'fatchul.amin1@gmail.com', 'user', NULL, NULL, NULL, '', NULL, '2017-04-19 14:41:58', '2017-04-19 09:41:49', '8kx2hVJ9Qo5PZK0rfSNSikyelnMFXZ2K8qv1gBNZSUpJjCCNmT', '$2y$12$dCuLmaZP9cYNn0rR.zJSYucToH5Jn0JeGbTXjNCvVU5lPKEJKhUNa', 'user', NULL, NULL, NULL, '1', '0');
INSERT INTO `user` (`id_user`, `id_school`, `email`, `role`, `nama`, `dob`, `password`, `gender`, `profile`, `last_login`, `date_join`, `token_reg`, `token_forgot_pass`, `level`, `address`, `facebook_url`, `pict_name`, `is_subscribe`, `is_valid`) VALUES ('203510', '205325', 'fatchul.amin1@gmail.com', '1', NULL, '04/01/2017', '$2y$12$dACImfB38Tx7cODHrsMb.uzI9gaFszogxSFVWTVd/1cf3gQSLGBXe', 'L', 'profil', '2017-04-20 13:35:10', '2017-04-20 08:35:10', 'imMHPGi9EonK3zDY9r6W6rPUdB5ICOtEkLDe3VZQnTyywqbZDk', 'IbUHY0EnYoHaMBMsq6up75XEL0cSmwkI3XDJr1zFdVSAQ7lqx', '10', 'alamat', 'https://www.facebook.com', '1', '1', '1');


